package com.example.puneet.jashn;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SearchEventActivity extends AppCompatActivity {
    DatabaseReference eventRef;
    final String TAG = "MainActivity";
    CardView cTech,cSports,cBusiness,cParty,cMovie;
    List<Category> data;
    String userID;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_event);

        cTech = findViewById(R.id.cardViewTech);
        cSports = findViewById(R.id.cardViewSports);
        cBusiness = findViewById(R.id.cardViewBusiness);
        cParty = findViewById(R.id.cardViewParty);
        cMovie = findViewById(R.id.cardViewMovie);

        FirebaseDatabase mFirebaseDatabase;
        FirebaseAuth mAuth;
        FirebaseAuth.AuthStateListener mAuthListener;

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        eventRef = FirebaseDatabase.getInstance().getReference();
        userID = user.getUid();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if(user!=null) {
                    Log.d(TAG, "onAuthStateChanged: Signedin "+user.getUid());
//                    Toast.makeText(SearchEventActivity.this, "Su", Toast.LENGTH_SHORT).show();
                }else {
                    Log.d(TAG, "onAuthStateChanged: Signed out");
                }
            }
        };


        cTech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCardClick("Tech");
            }
        });

        cSports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCardClick("Sports");
            }
        });

        cBusiness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCardClick("Business");
            }
        });

        cParty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCardClick("Party");
            }
        });

        cMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCardClick("Movie");
            }
        });
    }
    public void onCardClick(final String choice){
        data = new ArrayList<Category>();
        eventRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Event event = dataSnapshot.getValue(Event.class);
                for(DataSnapshot ds:dataSnapshot.getChildren()){
                    Category category = new Category();
                    String cat = ds.child("events").getValue(Event.class).getCategory();
                    if (cat.equals(choice)){
                    category.setDate(ds.child("events").getValue(Event.class).getDate());
                    category.setEventName(ds.child("events").getValue(Event.class).getEventName());
                    category.setEventDetail(ds.child("events").getValue(Event.class).getDescription());
                        Log.d(TAG, "onDataChange: searchactivi" + ds.child("events").getValue(Event.class).getEventName());
                    data.add(category);
                    }
                }
                Intent intent = new Intent();
                intent.putExtra("categoryList", (Serializable) data);
                startActivity(new Intent(SearchEventActivity.this,CategoryActivity.class));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
