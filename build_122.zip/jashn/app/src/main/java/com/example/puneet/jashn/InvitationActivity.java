package com.example.puneet.jashn;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Ref;
import java.util.HashMap;
import java.util.Map;

public class InvitationActivity extends AppCompatActivity {

    private String date;
    private String time;
    private String venue;
    private String guests;
    private String description;
    TextView eDate, eTime, eVenue, eGuests, eDescription;
    TextView eDateVal, eTimeVal, eVenueVal, eGuestsVal, eThemeVal;
    Button bAccept, bDecline;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitation);

        eDate = findViewById(R.id.dateView);
        eTime = findViewById(R.id.timeView);
        eVenue = findViewById(R.id.venueView);
        eGuests = findViewById(R.id.guestsView);
        eDescription = findViewById(R.id.descView);
        bAccept = findViewById(R.id.acceptButton);
        bDecline = findViewById(R.id.declineButton);
        eDateVal = findViewById(R.id.dateValue);
        eTimeVal = findViewById(R.id.timeValue);
        eVenueVal = findViewById(R.id.venueValue);
        eGuestsVal = findViewById(R.id.guestsValue);
        eThemeVal = findViewById(R.id.themeValue);
        final String userID = "-LR4rLwn4FDCcNizoL6V";
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
//        DatabaseReference eventRef = ref.child("events");
//        DatabaseReference profileRef = ref.child("profiles");

// Attach a listener to read the data at your profile reference
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Event event = dataSnapshot.getValue(Event.class);
                Invitation invite = new Invitation();
                invite.setDate(event.getDate());
                invite.setTime(event.getTime());
                invite.setDescription(event.getDescription());
                invite.setGuests(event.getGuests());
                invite.setVenue(event.getLocation());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
        bAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Event event = new Event();
//                Profile profile = new Profile();
//                Map<String,String> hash = new HashMap<>();
//                hash.put("-LScsUonhXatq-Ig7Zd12D","-LScsUonhXatq-Ig7ZdD");
//                profile.setActevnt(hash);

                ref.child("profiles").child(userID).child("acceptedEvent").push().setValue("-LScsUonhXatq-Ig7ZdfdgdgD");//getEventID karni hai
//                String id = ref.child("profiles").child(userID).child("acceptedEvent").getKey();
//                ref.child("profiles").child(userID).child("acceptedEvent").child(id).setValue(event.getDate());
//                ref.child("profiles").child(userID).child("acceptedEvent").child(id).setValue(event.getEventName());
//                ref.child("profiles").child(userID).child("acceptedEvent").child(id).push().setValue(event.getDescription());
                Toast.makeText(InvitationActivity.this,"Event Accepted",Toast.LENGTH_SHORT).show();
                bAccept.setVisibility(View.GONE);
            }
        });

    }

}