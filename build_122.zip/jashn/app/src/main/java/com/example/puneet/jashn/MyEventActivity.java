package com.example.puneet.jashn;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class MyEventActivity extends AppCompatActivity {
    DatabaseReference eventRef;
    TextView eDate,eTime,eTitle,eCategory,eHost;
    String userID;
    private static final String TAG = "MyEventActivity";
    ArrayList<String> usercreatedevents;
    ArrayList<String> useracceptedevents;
    ArrayList<MyEvent> MyEvents;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myevent_home);
        FirebaseDatabase mFirebaseDatabase;
        FirebaseAuth mAuth;
        FirebaseAuth.AuthStateListener mAuthListener;

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        eventRef = FirebaseDatabase.getInstance().getReference();
        userID = user.getUid();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if(user!=null) {
                    Log.d(TAG, "onAuthStateChanged: Signedin "+user.getUid());
//                    Toast.makeText(SearchEventActivity.this, "Su", Toast.LENGTH_SHORT).show();
                }else {
                    Log.d(TAG, "onAuthStateChanged: Signed out");
                }
            }
        };

        useracceptedevents = new ArrayList<String>();
        useracceptedevents = new ArrayList<String>();
        MyEvents = new ArrayList<MyEvent>();
        eventRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Profile profile = dataSnapshot.getValue(Profile.class);
                for(DataSnapshot ds:dataSnapshot.getChildren()){
                    String user = ds.child("profiles").getValue(Profile.class).getProfileID();
                    if(user.equals(userID)) {
                        String acceptevents = eventRef.child("profiles").child(userID).child("acceptedEvent").getKey();
                        String createdevents = eventRef.child("profiles").child(userID).child("createdEvent").getKey();
                        useracceptedevents.add(acceptevents);
                        usercreatedevents.add(createdevents);
                    }
                }

                    MyEvent myEvent = new MyEvent();
                    Event event = dataSnapshot.getValue(Event.class);
                for (DataSnapshot ds:dataSnapshot.getChildren()){
                    for (String events :useracceptedevents){
                        String eveID = ds.child("events").getValue(Event.class).getEventID();
                        if (eveID.equals(events)){
                            myEvent.setDate(ds.child("events").getValue(Event.class).getDate());
                            myEvent.setTitle(ds.child("events").getValue(Event.class).getEventName());
                            myEvent.setDescription(ds.child("events").getValue(Event.class).getDescription());
                            Log.d(TAG, "onDataChange: title " + ds.child("events").getValue(Event.class).getEventName());
                            MyEvents.add(myEvent);
                        }
                    }
                    for (String events :usercreatedevents){
                        String eveID = ds.child("events").getValue(Event.class).getEventID();
                        if (eveID.equals(events)){
                            myEvent.setDate(ds.child("events").getValue(Event.class).getDate());
                            myEvent.setTitle(ds.child("events").getValue(Event.class).getEventName());
                            myEvent.setDescription(ds.child("events").getValue(Event.class).getDescription());
                            Log.d(TAG, "onDataChange: title " + ds.child("events").getValue(Event.class).getEventName());
                            MyEvents.add(myEvent);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
