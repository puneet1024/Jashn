package com.example.puneet.jashn;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {

    private List<Category> dataModelList;
    private Context mContext;
    Category category;

    public CategoryAdapter(List<Category> list, Context context) {
        dataModelList = list;
        mContext = context;
    }

    // View holder class whose objects represent each list item

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView dateTextView;
        public TextView nameTextView;
        public TextView detailTextView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.event_photo);
            nameTextView = itemView.findViewById(R.id.event_name);
            detailTextView = itemView.findViewById(R.id.event_detail);
        }

//        public void bindData(Category category, Context context) {
//            dateTextView.setText(category.getDate());
//            nameTextView.setText(category.getEventName());
//            detailTextView.setText(category.getEventDetail());
//
//        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate out card list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        // Return a new view holder
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        // Bind data for the item at position
//        holder.bindData(dataModelList.get(position), mContext);
        holder.dateTextView.setText(dataModelList.get(position).getDate());
        holder.detailTextView.setText(dataModelList.get(position).getEventDetail());
        holder.nameTextView.setText(dataModelList.get(position).getEventName());
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public int getItemCount() {
        // Return the total number of items
        return dataModelList.size();
    }
}