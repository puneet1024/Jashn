//package com.example.puneet.jashn;
//
//import android.content.Context;
//import android.support.annotation.NonNull;
//import android.support.v7.widget.RecyclerView;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import java.util.List;
//
//public class MyEventAdapter {
//    private List<MyEvent> dataModelList;
//    private Context mContext;
//    MyEvent myEvent;
//
//    public MyEventAdapter(List<Category> list, Context context) {
//        dataModelList = list;
//        mContext = context;
//    }
//
//    // View holder class whose objects represent each list item
//
//    public static class MyViewHolder extends RecyclerView.ViewHolder {
//        public TextView dateTextView;
//        public TextView nameTextView;
//        public TextView detailTextView;
//
//        public MyViewHolder(@NonNull View itemView) {
//            super(itemView);
//            dateTextView = itemView.findViewById(R.id.event_photo);
//            nameTextView = itemView.findViewById(R.id.event_name);
//            detailTextView = itemView.findViewById(R.id.event_detail);
//        }
//
//        public void bindData(MyEvent myEvent, Context context) {
//            dateTextView.setText(myEvent.getDate());
//            nameTextView.setText(myEvent.getTitle());
//            detailTextView.setText(myEvent.getDescription());
//
//        }
//    }
//
//    @NonNull
//    @Override
//    public CategoryAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        // Inflate out card list item
//        View view = LayoutInflater.from(parent.getContext())
//                .inflate(R.layout.list_item, parent, false);
//        // Return a new view holder
//        return new CategoryAdapter.MyViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull CategoryAdapter.MyViewHolder holder, int position) {
//        // Bind data for the item at position
//        holder.bindData(dataModelList.get(position), mContext);
//        holder.dateTextView.setText(myEvent.getDate());
//        holder.detailTextView.setText(myEvent.getDescription());
//        holder.nameTextView.setText(myEvent.getTitle());
//    }
//
//    @Override
//    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
//        super.onAttachedToRecyclerView(recyclerView);
//    }
//
//    @Override
//    public int getItemCount() {
//        // Return the total number of items
//        return dataModelList.size();
//    }
//}
