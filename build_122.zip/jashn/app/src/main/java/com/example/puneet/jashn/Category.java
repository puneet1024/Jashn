package com.example.puneet.jashn;

import java.util.Locale;

public class Category {
    private String date;
    private String eventName;
    private String eventDetail;


    public Category(){

    }

    public Category(String date, String eventName, String eventDetail) {
        this.date = date;
        this.eventName = eventName;
        this.eventDetail = eventDetail;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDetail() {
        return eventDetail;
    }

    public void setEventDetail(String eventDetail) {
        this.eventDetail = eventDetail;
    }
}
